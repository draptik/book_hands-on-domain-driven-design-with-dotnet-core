# Hands-on DDD with C# book code

The book is **work in progress** and as I am working through
chapters, the code will change.

The code is cplit per chapter using folders (despite what I wrote before about using history and branches).

The book is currently available as [early access eBook](https://www.packtpub.com/application-development/hands-domain-driven-design-net).
