# Hands-on DDD with C# book code

The book is **work in progress** and as I am working through
chapters, the code will change.

The book will contain almost everything from the history of this repository so
I have no plans to have code per chapter.

The book is currently available as [early access eBook](https://www.packtpub.com/application-development/hands-domain-driven-design-net).
