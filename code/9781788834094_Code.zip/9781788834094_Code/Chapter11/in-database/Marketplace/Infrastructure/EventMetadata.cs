namespace Marketplace.Infrastructure
{
    public class EventMetadata
    {
        public string ClrType { get; set; }
    }
}