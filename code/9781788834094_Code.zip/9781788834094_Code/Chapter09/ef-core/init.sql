CREATE DATABASE "Marketplace_Chapter9";
CREATE USER ddd WITH PASSWORD 'book';
GRANT ALL PRIVILEGES ON DATABASE "Marketplace_Chapter9" to ddd;
