namespace Marketplace.Domain.Shared
{
    public delegate bool CheckTextForProfanity(string text);
}