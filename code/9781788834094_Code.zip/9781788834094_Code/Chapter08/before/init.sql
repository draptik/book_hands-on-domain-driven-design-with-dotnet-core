CREATE DATABASE "Marketplace_Chapter8";
CREATE USER ddd WITH PASSWORD 'book';
GRANT ALL PRIVILEGES ON DATABASE "Marketplace_Chapter8" to ddd;
